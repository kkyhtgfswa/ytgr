# heroku-xray-vless

Deploy VLESS server to heroku

#

<p><a href="https://dashboard.heroku.com/new?template=https://github.com/louyour/dan-xray-vless"> <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku" /></a></p>



⭕ ɢᴇɴᴇʀᴀᴛᴇ ᴠ2ʀᴀʏ ᴜᴜɪᴅ ᴜꜱɪɴɢ ᴛʜɪꜱ ᴡᴇʙꜱɪᴛᴇ.https://www.uuidgenerator.net/

______
# ᴄᴏɴꜰɪɢᴜʀᴀᴛɪᴏɴ
```
* 代理协议(类型)：vless 
* 地址(Address)：appname.herokuapp.com
* 端口(Port)：443
* UUID：*ʏᴏᴜ ᴀᴅᴅᴇᴅ ᴜᴜɪᴅ*
* 流控(Flow): xtls-rprx-direct
* 加密(encryption)：none
* 传输协议(Transport)：ws
* 伪装类型：none
* 路径：/
* 底层传输安全：tls
________

