# heroku-vless
Deploy VLESS server to heroku

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://dashboard.heroku.com/new?template=https://github.com/louyour/dan-vless/edit/main)


```
* 代理协议(类型)：vless 
* 地址(Address)：appname.herokuapp.com
* 端口(Port)：443
* 默认UUID：1309c705-61ff-47d3-bab9-67a377e403db
* 流控(Flow): xtls-rprx-direct
* 加密(encryption)：none
* 传输协议(Transport)：ws
* 伪装类型：none
* 路径：/
* 底层传输安全：tls

